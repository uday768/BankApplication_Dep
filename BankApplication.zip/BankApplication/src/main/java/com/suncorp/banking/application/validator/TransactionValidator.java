package com.suncorp.banking.application.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;

import com.suncorp.banking.application.dto.FundsDTO;

@Component
public class TransactionValidator {

	public void validate(FundsDTO fundsDTO, Errors errors) {
		if ("TPT".equals(fundsDTO.getTransactionType()) && "" != fundsDTO.getBeneficiaryAccountNumber()) {
			errors.reject("Beneficiary Account Number is required for the money transfer");
			//errors.rejectValue("beneficiaryAccountNumber", "Beneficiary Account Number is required for the money transfer");
		}
	}
}
