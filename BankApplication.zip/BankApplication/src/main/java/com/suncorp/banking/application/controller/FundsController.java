package com.suncorp.banking.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.suncorp.banking.application.service.FundsService;
import com.suncorp.banking.application.vo.AccountVo;

@RestController
@RequestMapping("/account/funds")
public class FundsController {

	@Autowired
	FundsService fundsService;
	
	@ResponseBody
	@RequestMapping(value = "/deposit", method = RequestMethod.POST)
	public String viewFunds(@RequestBody AccountVo accountVo){
		
		fundsService.depositFunds(accountVo);
		
		return "Inside deposit account";
	}
}
