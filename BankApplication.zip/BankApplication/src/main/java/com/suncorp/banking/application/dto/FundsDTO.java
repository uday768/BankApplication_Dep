package com.suncorp.banking.application.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class FundsDTO {

	//@NotNull(message = "Transaction Type cannot be null")
	@NotBlank(message = "Transaction type cannot be blank.")
	private String transactionType;

	private String beneficiaryAccountNumber;

	@NotNull(message = "Amount cannot be null")
	@Positive(message = "Amount should be greate that zero")
	private double fund;

	public FundsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FundsDTO(String transactionType, String beneficiaryAccountNumber, double fund) {
		super();
		this.transactionType = transactionType;
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
		this.fund = fund;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getBeneficiaryAccountNumber() {
		return beneficiaryAccountNumber;
	}

	public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
		this.beneficiaryAccountNumber = beneficiaryAccountNumber;
	}

	public double getFund() {
		return fund;
	}

	public void setFund(double fund) {
		this.fund = fund;
	}

}