package com.suncorp.banking.application.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.suncorp.banking.application.repo.AccountRepository;
import com.suncorp.banking.application.vo.AccountVo;

@Service
public class FundsService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private AccountRepository accountRepo;
	
	
	public void depositFunds(AccountVo fundDetails) {
		logger.info("Checking the whether the account exists or not");
		AccountVo findAccountByAccountNumber = accountRepo
				.findAccountByAccountNumber(fundDetails.getAccountNumber());
		logger.info("Account details are-->" + findAccountByAccountNumber.toString());
		double updatedBalance = findAccountByAccountNumber.getBalance()+fundDetails.getBalance();
		findAccountByAccountNumber.setBalance(updatedBalance);
		accountRepo.save(findAccountByAccountNumber);
	}
}
