package com.suncorp.banking.application.validations;

public interface NullNotAllowed {

}
