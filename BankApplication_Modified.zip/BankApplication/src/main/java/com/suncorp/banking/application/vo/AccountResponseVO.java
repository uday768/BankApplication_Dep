package com.suncorp.banking.application.vo;

public class AccountResponseVO {

	private String accountNumber, accountType, message, reference;

	public AccountResponseVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public AccountResponseVO(String accountNumber, String accountType, String message) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.message = message;
	}



	public AccountResponseVO(String accountNumber, String accountType, String message, String reference) {
		super();
		this.accountNumber = accountNumber;
		this.accountType = accountType;
		this.message = message;
		this.reference = reference;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

}